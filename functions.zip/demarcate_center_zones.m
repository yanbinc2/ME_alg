%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Demarcate the center zone of data points in a Euclidean space.
% Input is the coordinates of data points.
% Output is the data point indices belonging to the center zone.
% Vary the threshold value of distances between points.
% For each threshold generate a graph.
% Find connected components for each graph.
% Trace the inheritance lineages of the connected components.
% Find the branch point with the greatest split.
% Trace lineage from root to the branch point.
% If no such branch point exists, then trace the largest lineage from root to a leaf.
% The clusters belonging to the bottom of the lineage belong to the center zone.
% Determine whether to include other clusters spinned off from the major lineage in the center zone.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function centerzonemembers = demarcate_center_zones(data, theta, theta2, sizethre)

[nnodes,ndim]=size(data);
D=pdist(data,'euclidean');
D=squareform(D);

threvals=transpose(sort(unique(D(:)),'descend'));


% Establish the cluster lineage data structure.
% clustermembers{ind}: member data points of cluster ind.
% timecodes(ind,1:2): birth and death times of cluster ind.
% clusterchildren{ind}: children of cluster ind.
% clusterpas(ind): parent of cluster ind.
% Stop when <= active 1 component has size > a threshold.
% Stop when the threshold <= thetathre percentile of distances.

nclusters=0; clustermembers={}; timecodes=zeros(1,2); clusterchildren={}; clusterpas=[];
t=1; flag=1; active=[]; 
stopthre=quantile(D(:),theta);

% Debug
%fprintf('stopthre=%f\n',stopthre);

while (flag==1)

 thre=threvals(t);
 G=zeros(nnodes,nnodes);
 G(find(D<=thre))=1;
 [ncs,cs]=find_conn_comps(nnodes,G);
 
 oldactive=active;
 tmpactive=active;

 newsizes=[];

 for i=1:ncs
  j=1; k=0;
  while ((j<=nclusters)&(k==0))
   if (active(j)==1)
    if (length(intersect(cs{i}.comps,clustermembers{j}))==length(cs{i}.comps))
     k=j;
    end
   end
   j=j+1;
  end
  if (k==0)
   nclusters=nclusters+1;
   clustermembers{nclusters}=cs{i}.comps;
   if (nclusters==1)
    timecodes(nclusters,:)=[1 0];
   else
    timecodes(nclusters,:)=[t 0];
   end
   clusterchildren{nclusters}=[];
   clusterpas(nclusters)=0;
   active(nclusters)=1;
  else
   if (isequal(cs{i}.comps,clustermembers{k})==1)
    timecodes(k,2)=t;
   else
    nclusters=nclusters+1;
    clustermembers{nclusters}=cs{i}.comps;
    timecodes(nclusters,:)=[t 0];
    clusterchildren{nclusters}=[];
    clusterpas(nclusters)=k;
    active(nclusters)=1;
    clusterchildren{k}=[clusterchildren{k} nclusters];
    tmpactive(k)=0;

    newsizes=[newsizes length(cs{i}.comps)];

   end
  end
 end
 ss=find((oldactive==1)&(tmpactive==0));
 timecodes(ss,2)=t;
 active(ss)=0;


 % Apply binary search to find the next threshold value that further splits the data.
 t1=t; t2=length(threvals);
 curncs=ncs; nextt=0;
 while (nextt==0)
  thre=threvals(t1);
  G=zeros(nnodes,nnodes);
  G(find(D<=thre))=1;
  [ncs1,cs1]=find_conn_comps(nnodes,G);
  thre=threvals(t2);
  G=zeros(nnodes,nnodes);
  G(find(D<=thre))=1;
  [ncs2,cs2]=find_conn_comps(nnodes,G);
  mt=round((t1+t2)/2);
  thre=threvals(mt);
  G=zeros(nnodes,nnodes);
  G(find(D<=thre))=1;
  [ncs3,cs3]=find_conn_comps(nnodes,G);
  
  if (mt==t2)
   nextt=t2;
  elseif (ncs3>curncs)
   t2=mt;
  elseif (ncs3==curncs)
   t1=mt;
  end
 end
 
 t=nextt;

 thre=threvals(t);
 if (thre<stopthre)
  flag=0;
 end

    
end


% Return all data points if nclusters=1.
if (nclusters==1)
 k=length(data(:,1));
 centerzonemembers=1:k;
 return;
end


% Count cluster sizes and split sizes.

clustersizes=zeros(1,nclusters);
for n=1:nclusters
 clustersizes(n)=length(clustermembers{n});
end

splitsizes=zeros(nclusters,2);
for n=1:nclusters
 children=clusterchildren{n};
 if (length(children)>2)
  children=children(1:2);
 end
 if (length(children)>0)
  splitsizes(n,:)=clustersizes(children);
 end
end


% Trace the largest lineage.
lineage=[1]; flag=1; curind=1;
while (flag==1)
 children=clusterchildren{curind};
 if (length(children)<=0)
  flag=0;
 else
  clsizes=clustersizes(children);
  k=find(clsizes>=max(clsizes));
  if (length(k)>1)
   flag=0;
  else
   curind=children(k);
   lineage=[lineage curind];
  end
 end
end


% Count the sizes of majority and minority children of each branch point.
% If all branch points along the lineage have minority children size < sizethre, then then all branches are very biased splits.  Terminate the lineage at the bottom.
% If some branch points along the lineage have minority children size >= sizethre, then extract these branch points and find the one at the highest level.
% Proceed one more step if this branch point is not at the bottom.
% However, if the threshold distance corresponding to the chosen split is smaller than the largest distance times theta, then the two children clusters are too close.  Step back k.

minsizes=min(transpose(splitsizes(lineage,:)));
if (sum(minsizes>=sizethre)==0)
 k=length(lineage);
else
 tt=find(minsizes>=sizethre);
 k=min(tt); 
 if (k<length(lineage))
  k=k+1;
 end
end



lineage=lineage(1:k);


% At each branch point, check whether to include the minor child cluster in the center zone.
% The branch point splits into major and minor children clusters.
% Calculate the mean distance between each point in major and minor children clusters within the same cluster and in another cluster.
% Count the fraction of major children cluster members whose mean distances to the minor children cluster are smaller than the mean distances to the major children cluster.
% If this fraction is small, then the minor children cluster is located outside the major children cluster.

covered=zeros(1,nclusters); ind=1;
while (ind<=(length(lineage)-1))
 curind=lineage(ind);
 children=clusterchildren{curind};
 i1=lineage(ind+1); i2=setdiff(children,i1);
 set1=clustermembers{i1}; set2=clustermembers{i2};
 sD1=zeros(length(set1),2);
 for i=1:length(set1)
  v1=setdiff(set1,set1(i));
  v2=set2;
  tD=D(set1(i),v1); sD1(i,1)=mean(tD);
  tD=D(set1(i),v2); sD1(i,2)=mean(tD);
 end
 sD2=zeros(length(set2),2);
 for i=1:length(set2)
  v1=setdiff(set2,set2(i));
  v2=set1;
  tD=D(set2(i),v1); sD2(i,1)=mean(tD);
  tD=D(set2(i),v2); sD2(i,2)=mean(tD);
 end
 m1=length(set1); n1=sum(sD1(:,1)>sD1(:,2));
 m2=length(set2); n2=sum(sD2(:,1)>sD2(:,2));
 if (n1>=(m1*theta2))
  covered(i2)=1;
 end
 covered(i1)=1;
 ind=ind+1;
end


% Identify the minority children clusters along the lineage which are not covered.
exinds=[];
for m=1:(length(lineage)-1)
 n=lineage(m);
 children=clusterchildren{n};
 i1=lineage(m+1); i2=setdiff(children,i1);
 if (covered(i2)==0)
  exinds=[exinds i2];
 end
end


% Find the center zone members.
% Find the top node along the lineage which is covered.  Extract its members.
% Subtract the members of exinds from the members obtained in the previous step.

m=1; ind=0;
while ((m<=length(lineage))&(ind==0))
 n=lineage(m);
 if (covered(n)==1)
  ind=n;
 end
 m=m+1;
end


centerzonemembers=clustermembers{ind};
for m=1:length(exinds)
 n=exinds(m); subset=clustermembers{n};
 centerzonemembers=setdiff(centerzonemembers,subset);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Merge seed regions for an example MNIST dataset.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear;

directory='/mnt/sdb/NN/package_version3/data/';


% Load MNIST data and spectral cluster labels.

% Load t-SNE projection data.
datafilename=sprintf('%sMNIST_tSNE.csv',directory);
augdatafileinfoname='dummy';

% Load spectral cluster labels.
clustersfilename=sprintf('%sMNIST_SpectralLabel.csv',directory);


% Load valid seed indices and their labels.
seedindsfilename=sprintf('%sMNIST_seedinds_valid.txt',directory);


% Load bilabels of regions.
bilabelsfilename=sprintf('%sMNIST_bilabels.txt',directory);


% The parameter values are storted in a file.
parametersfilename=sprintf('%sMNIST_merge_seedregions_params.txt',directory);


% Load seed indices and their labels.
seedinds=load(seedindsfilename);
seedinds=transpose(seedinds);
nseeds=length(seedinds);


% Set the file names of prediction outcomes of seed regions.
originalpredresultsfilename=sprintf('%sMNIST_results_original.mat',directory);
combpredresultsfilename=sprintf('%sMNIST_results_combination.mat',directory);
removepredresultsfilename=sprintf('%sMNIST_results_removal.mat',directory);



% The merged seed regions are stored in a file.
mergedclasslabelsfilename=sprintf('%sMNIST_mergedseedclasslabels.txt',directory);


% Load the input data.
filename=sprintf('%s',datafilename);
fp=fopen(filename,'r');
s=fgets(fp);
ndim=sum(s==',')+1;
fseek(fp,0,-1);
form=[repmat('%f',1,ndim)];
de=sprintf(',');
cells=textscan(fp,form,'Delimiter',de,'Headerlines',1,'TreatAsEmpty',{'NA','na'});
fclose(fp);
ndim=length(cells); nimages=length(cells{1});
data=NaN*ones(nimages,ndim);
for i=1:ndim
 data(:,i)=transpose(cells{i});
end


% Load the augmented data if the file exists.
filename=sprintf('%s',augdatafileinfoname);
fp=fopen(filename,'r');
if (fp<0)
 augdata=[];
else
 s=fgets(fp);
 augdirectory=s(1:(length(s)-1));
 s=fgets(fp);
 prefix=s(1:(length(s)-1));
 s=fgets(fp);
 naugmentations=atof2(s);
 fclose(fp);
 filename=sprintf('%s%s_001.csv',augdirectory,prefix);
 fp=fopen(filename,'r');
 if (fp<0)
  augdata=[];
 else
  fclose(fp);
  for ind=1:naugmentations
   str2=sprintf('%d',ind);
   l2=length(str2); l1=3-l2;
   str1=repmat('0',1,l1);
   str=sprintf('%s%s',str1,str2);
   filename=sprintf('%s%s_%s.csv',augdirectory,prefix,str);
   fp=fopen(filename,'r');
   form=[repmat('%f',1,ndim)];
   de=sprintf(',');
   cells=textscan(fp,form,'Delimiter',de,'Headerlines',1,'TreatAsEmpty',{'NA','na'});
   fclose(fp);
   augdata(:,:,ind)=NaN*ones(nimages,ndim);
   for i=1:ndim
    augdata(:,i,ind)=transpose(cells{i});
   end
  end
 end
end


% Load cluster labels of data points.
% Also load the true labels of data points.
% Find dominant class labels of regions.
filename=sprintf('%s',clustersfilename);
fp=fopen(filename,'r');
form=['%s','%d','%s'];
de=sprintf(',');
cells=textscan(fp,form,'Delimiter',de,'Headerlines',1,'TreatAsEmpty',{'NA','na'});
fclose(fp);
regionneighborlabels=cells{2};
regionneighborlabels=transpose(regionneighborlabels);
nregions=max(regionneighborlabels);


% Obtain class labels of images.
imagelabels=zeros(1,nimages);
ulabels={}; nulabels=0;
for n=1:nimages
 str=cells{3}{n};
 str=str(2:(length(str)-1));
 [a,b]=ismember(str,ulabels);
 if (b<=0)
  nulabels=nulabels+1;
  ulabels{nulabels}=str;
  imagelabels(n)=nulabels;
 else
  imagelabels(n)=b;
 end
end

% Sort the class labels and reorder imagelabels.
[Y,I]=sort(ulabels);
I=1:nulabels;
sortedulabels=ulabels(I);
sortedinds=zeros(1,nulabels);
for i=1:nulabels
 j=I(i); sortedinds(j)=i;
end

sortedimagelabels=zeros(1,nimages);
for n=1:nimages
 i=imagelabels(n);
 j=sortedinds(i);
 sortedimagelabels(n)=j-1;
end

imagelabels=sortedimagelabels;
clear sortedimagelabels;
ulabels=sortedulabels;
clear sortedulabels;


% Load the CNN prediction outcomes.
load(originalpredresultsfilename);
load(combpredresultsfilename);
load(removepredresultsfilename);



% Load paramters from an input file.
vals=load(parametersfilename);
regionpairDmode=vals(1);
usemarker=vals(2);
nprednumthre=vals(3);
pvalthre=vals(4);
nothersthre=vals(5);
cssizethre=vals(6);
ntoprankthre=vals(7);
quantilethre=vals(8);
nneighborsconsidered=vals(9);
ttestpvalthre=vals(10);
nuniquemarkersthre=vals(11);
importthre=vals(12);
replacementratiothre=vals(13);
localranksumpvalthre=vals(14);
cocontributionthre=vals(15);
reducedrankscorethre=vals(16);
confusionratiothre=vals(17);
ndiffthre=vals(18); 
Hdthre=vals(19); 
rankthre=vals(20); 
datavalthre=vals(21); 
datavaldiffthre=vals(22);
foldthre=vals(23); 
cntthre=vals(24);
gapthre=vals(25); 
maxgapcntthre=vals(26); 
gapcntdiffthre=vals(27);
sizethre=vals(28); 
jumpfoldthre=vals(29); 
smallclustersizethre=vals(30); 
gapfoldthre=vals(31);
smallratiothre=vals(32);
pdiffthre=vals(33);
pdiffthre2=vals(34);
medvalthre=vals(35);
ninformativemarkersthre=vals(36);
ninformativemarkersthre2=vals(37);
cntdiffthre=vals(38);



% Load bilabels.
bilabels=load(bilabelsfilename);

regiontraininglabels=zeros(1,nimages);
for n=1:nregions
 ss=find((bilabels(:,1)==n)&(bilabels(:,2)==1));
 regiontraininglabels(ss)=n;
end



% Find the dominant class labels of regions and counts of class labels of regions.
regionlabels=zeros(1,nregions);
regionlabelcnts=zeros(nregions,nulabels);
for n=1:nregions
 ss=find((bilabels(:,1)==n)&(bilabels(:,2)==1));
 vec=zeros(1,nulabels);
 for i=1:nulabels
  k=sum(imagelabels(ss)==i);
  vec(i)=k;
 end
 regionlabelcnts(n,:)=vec;
 [Y,I]=sort(vec,'descend');
 if (Y(1)>=(length(ss)*0.6))
  regionlabels(n)=I(1);
 end
end



% Calculate region pair distances by blocks.
regionpairD=zeros(nregions,nregions);
blocksize=10; nblocks=round(nregions/blocksize);

for n=1:nblocks

 i1=(n-1)*blocksize+1; i2=min(i1+blocksize-1,nregions);
 k=0; X=zeros(1,ndim); labels=zeros(1,1);
 for i=i1:i2
  if (regionpairDmode==0)
   ss=find(regionneighborlabels==i);
  else
   ss=find(regiontraininglabels==i);
  end
  if (length(ss)==0)
   ss=find(regionneighborlabels==i);
  end
  for j=1:length(ss)
   vec=data(ss(j),:);
   k=k+1; X(k,:)=vec; labels(1,k)=i;
  end
 end
 D=pdist(X,'euclidean');
 D=squareform(D);
 for i=i1:i2
  for j=(i+1):i2
   s1=find(labels==i); s2=find(labels==j);
   tmpD=D(s1,s2);
   val=mean(tmpD(:));
   regionpairD(i,j)=val;
   regionpairD(j,i)=val;
  end
 end

end


for n=1:nblocks
 i1=(n-1)*blocksize+1; i2=min(i1+blocksize-1,nregions);
 k=0; X1=zeros(1,ndim); labels1=zeros(1,1);
 for i=i1:i2
  if (regionpairDmode==0)
   ss=find(regionneighborlabels==i);
  else
   ss=find(regiontraininglabels==i);
  end
  if (length(ss)==0)
   ss=find(regionneighborlabels==i);
  end
  for j=1:length(ss)
   vec=data(ss(j),:);
   k=k+1; X1(k,:)=vec; labels1(1,k)=i;
  end
 end
 for m=(n+1):nblocks  

  j1=(m-1)*blocksize+1; j2=min(j1+blocksize-1,nimages);
  k=0; X2=zeros(1,ndim); labels2=zeros(1,1);
  for i=j1:j2
   if (regionpairDmode==0)
    ss=find(regionneighborlabels==i);
   else
    ss=find(regiontraininglabels==i);
   end
   if (length(ss)==0)
    ss=find(regionneighborlabels==i);
   end
   for j=1:length(ss)
    vec=data(ss(j),:);    
    k=k+1; X2(k,:)=vec; labels2(1,k)=i;
   end
  end
 
  X=[X1;X2]; D=pdist(X,'euclidean'); D=squareform(D);
  sD=D(1:length(labels1),(length(labels1)+1):(length(labels1)+length(labels2)));

  for i=i1:i2
   for j=j1:j2
    s1=find(labels1==i); s2=find(labels2==j);
    tmpD=sD(s1,s2);
    val=mean(tmpD(:));
    regionpairD(i,j)=val;
    regionpairD(j,i)=val;
   end
  end

 end
end



% Run merge_seedregions_package.m.

[nmergeoutcomes,mergedclasslabels]=merge_seedregions_package(nseeds,seedinds,result_for_original,prob_for_original,combination_pairs,result_for_merge,result_for_removal,data,markerranks,regionneighborlabels,regionpairD,regiontraininglabels,[],0,[],usemarker,nprednumthre,pvalthre,nothersthre,cssizethre,ntoprankthre,quantilethre,nneighborsconsidered,ttestpvalthre,nuniquemarkersthre,importthre,replacementratiothre,localranksumpvalthre,cocontributionthre,reducedrankscorethre,confusionratiothre,ndiffthre,Hdthre,rankthre,datavalthre,datavaldiffthre,foldthre,cntthre,gapthre,maxgapcntthre,gapcntdiffthre,sizethre,jumpfoldthre,smallclustersizethre,gapfoldthre,smallratiothre,pdiffthre,pdiffthre2,medvalthre,ninformativemarkersthre,ninformativemarkersthre2,cntdiffthre);



% Report the merged seed classes.

filename=sprintf('%s',mergedclasslabelsfilename);
fout=fopen(filename,'w');
fprintf(fout,'index%cclass\n',9);
for n=1:nseeds
 fprintf(fout,'%d%c%d\n',seedinds(n),9,mergedclasslabels(n));
end
fclose(fout);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Merge seed regions for an example CIFAR10 dataset.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear;

directory='/mnt/sdb/NN/package_version3/data/';


% Load CIFAR10 data and spectral cluster labels.
clustersfilename=sprintf('%sVGG16_CIFAR_SpectralLabel.csv',directory);


% Load VGG16 embedeed data.
datafilename=sprintf('%sVGG16_CIFAR.csv',directory);
%augdatafileinfoname=sprintf('%sCIFAR10_augdatafileinfo.txt',directory);


% Load seed indices and their labels.
seedindsfilename=sprintf('%sCIFAR10_seedinds.txt',directory);


% Load bilabels of regions.
bilabelsfilename=sprintf('%sCIFAR10_bilabels.txt',directory);


% The parameter values are storted in a file.
parametersfilename=sprintf('%sCIFAR10_merge_seedregions_params.txt',directory);


% Load seed indices and their labels.
seedinds=load(seedindsfilename);
seedinds=transpose(seedinds);
nseeds=length(seedinds);


% Set the file names of prediction outcomes of seed regions.
originalpredresultsfilename=sprintf('%sCIFAR10_K200_results_of_original_version2.mat',directory);
combpredresultsfilename=sprintf('%sCIFAR10_K200_results_of_combination_version2.mat',directory);
removepredresultsfilename=sprintf('%sCIFAR10_K200_results_of_removal_version2.mat',directory);



% The merged seed regions are stored in a file.
mergedclasslabelsfilename=sprintf('%sCIFAR10_mergedseedclasslabels.txt',directory);


% Load the input data.
filename=sprintf('%s',datafilename);
fp=fopen(filename,'r');
s=fgets(fp);
ndim=sum(s==',')+1;
fseek(fp,0,-1);
form=[repmat('%f',1,ndim)];
de=sprintf(',');
cells=textscan(fp,form,'Delimiter',de,'Headerlines',1,'TreatAsEmpty',{'NA','na'});
fclose(fp);
ndim=length(cells); nimages=length(cells{1});
data=NaN*ones(nimages,ndim);
for i=1:ndim
 data(:,i)=transpose(cells{i});
end


%{
% Load the augmented data if the file exists.
filename=sprintf('%s',augdatafileinfoname);
fp=fopen(filename,'r');
if (fp<0)
 augdata=[];
else
 s=fgets(fp);
 augdirectory=s(1:(length(s)-1));
 s=fgets(fp);
 prefix=s(1:(length(s)-1));
 s=fgets(fp);
 naugmentations=atof2(s);
 fclose(fp);
 filename=sprintf('%s%s_001.csv',augdirectory,prefix);
 fp=fopen(filename,'r');
 if (fp<0)
  augdata=[];
 else
  fclose(fp);
  for ind=1:naugmentations
   str2=sprintf('%d',ind);
   l2=length(str2); l1=3-l2;
   str1=repmat('0',1,l1);
   str=sprintf('%s%s',str1,str2);
   filename=sprintf('%s%s_%s.csv',augdirectory,prefix,str);
   fp=fopen(filename,'r');
   form=[repmat('%f',1,ndim)];
   de=sprintf(',');
   cells=textscan(fp,form,'Delimiter',de,'Headerlines',1,'TreatAsEmpty',{'NA','na'});
   fclose(fp);
   augdata(:,:,ind)=NaN*ones(nimages,ndim);
   for i=1:ndim
    augdata(:,i,ind)=transpose(cells{i});
   end
  end
 end
end
%}


% Load cluster labels of data points.
% Also load the true labels of data points.
% Find dominant class labels of regions.
filename=sprintf('%s',clustersfilename);
fp=fopen(filename,'r');
form=['%s','%d','%s'];
de=sprintf(',');
cells=textscan(fp,form,'Delimiter',de,'Headerlines',1,'TreatAsEmpty',{'NA','na'});
fclose(fp);
regionneighborlabels=cells{2};
regionneighborlabels=transpose(regionneighborlabels);
nregions=max(regionneighborlabels);


% Obtain class labels of images.
imagelabels=zeros(1,nimages);
ulabels={}; nulabels=0;
for n=1:nimages
 str=cells{3}{n};
 str=str(2:(length(str)-1));
 [a,b]=ismember(str,ulabels);
 if (b<=0)
  nulabels=nulabels+1;
  ulabels{nulabels}=str;
  imagelabels(n)=nulabels;
 else
  imagelabels(n)=b;
 end
end

% Sort the class labels and reorder imagelabels.
[Y,I]=sort(ulabels);
%I=1:nulabels;
sortedulabels=ulabels(I);
sortedinds=zeros(1,nulabels);
for i=1:nulabels
 j=I(i); sortedinds(j)=i;
end

sortedimagelabels=zeros(1,nimages);
for n=1:nimages
 i=imagelabels(n);
 j=sortedinds(i);
 sortedimagelabels(n)=j-1;
end

imagelabels=sortedimagelabels;
clear sortedimagelabels;
ulabels=sortedulabels;
clear sortedulabels;


% Load the CNN prediction outcomes.
load(originalpredresultsfilename);
load(combpredresultsfilename);
load(removepredresultsfilename);



% Load paramters from an input file.
vals=load(parametersfilename);
regionpairDmode=vals(1);
usemarker=vals(2);
nprednumthre=vals(3);
pvalthre=vals(4);
nothersthre=vals(5);
cssizethre=vals(6);
ntoprankthre=vals(7);
quantilethre=vals(8);
nneighborsconsidered=vals(9);
ttestpvalthre=vals(10);
nuniquemarkersthre=vals(11);
importthre=vals(12);
replacementratiothre=vals(13);
localranksumpvalthre=vals(14);
cocontributionthre=vals(15);
reducedrankscorethre=vals(16);
confusionratiothre=vals(17);
ndiffthre=vals(18); 
Hdthre=vals(19); 
rankthre=vals(20); 
datavalthre=vals(21); 
datavaldiffthre=vals(22);
foldthre=vals(23); 
cntthre=vals(24);
gapthre=vals(25); 
maxgapcntthre=vals(26); 
gapcntdiffthre=vals(27);
sizethre=vals(28); 
jumpfoldthre=vals(29); 
smallclustersizethre=vals(30); 
gapfoldthre=vals(31);
smallratiothre=vals(32);
pdiffthre=vals(33);
pdiffthre2=vals(34);
medvalthre=vals(35);
ninformativemarkersthre=vals(36);
ninformativemarkersthre2=vals(37);
cntdiffthre=vals(38);



% Load bilabels.
bilabels=load(bilabelsfilename);

regiontraininglabels=zeros(1,nimages);
for n=1:nregions
 ss=find((bilabels(:,1)==n)&(bilabels(:,2)==1));
 regiontraininglabels(ss)=n;
end



% Find the dominant class labels of regions and counts of class labels of regions.
regionlabels=-1*ones(1,nregions);
regionlabelcnts=zeros(nregions,nulabels);
for n=1:nregions
 ss=find((bilabels(:,1)==n)&(bilabels(:,2)==1));
 vec=zeros(1,nulabels);
 for i=1:nulabels
  k=sum(imagelabels(ss)==(i-1));
  vec(i)=k;
 end
 regionlabelcnts(n,:)=vec;
 [Y,I]=sort(vec,'descend');
 if (Y(1)>=(length(ss)*0.6))
  regionlabels(n)=I(1)-1;
 end
end


% Calculate region pair distances by blocks.
regionpairD=zeros(nregions,nregions);
blocksize=10; nblocks=round(nregions/blocksize);

for n=1:nblocks

 i1=(n-1)*blocksize+1; i2=min(i1+blocksize-1,nregions);
 k=0; X=zeros(1,ndim); labels=zeros(1,1);
 for i=i1:i2
  if (regionpairDmode==0)
   ss=find(regionneighborlabels==i);
  else
   ss=find(regiontraininglabels==i);
  end
  if (length(ss)==0)
   ss=find(regionneighborlabels==i);
  end
  for j=1:length(ss)
   vec=data(ss(j),:);
   k=k+1; X(k,:)=vec; labels(1,k)=i;
  end
 end
 D=pdist(X,'euclidean');
 D=squareform(D);
 for i=i1:i2
  for j=(i+1):i2
   s1=find(labels==i); s2=find(labels==j);
   tmpD=D(s1,s2);
   val=mean(tmpD(:));
   regionpairD(i,j)=val;
   regionpairD(j,i)=val;
  end
 end

end


for n=1:nblocks
 i1=(n-1)*blocksize+1; i2=min(i1+blocksize-1,nregions);
 k=0; X1=zeros(1,ndim); labels1=zeros(1,1);
 for i=i1:i2
  if (regionpairDmode==0)
   ss=find(regionneighborlabels==i);
  else
   ss=find(regiontraininglabels==i);
  end
  if (length(ss)==0)
   ss=find(regionneighborlabels==i);
  end
  for j=1:length(ss)
   vec=data(ss(j),:);
   k=k+1; X1(k,:)=vec; labels1(1,k)=i;
  end
 end
 for m=(n+1):nblocks  

  j1=(m-1)*blocksize+1; j2=min(j1+blocksize-1,nimages);
  k=0; X2=zeros(1,ndim); labels2=zeros(1,1);
  for i=j1:j2
   if (regionpairDmode==0)
    ss=find(regionneighborlabels==i);
   else
    ss=find(regiontraininglabels==i);
   end
   if (length(ss)==0)
    ss=find(regionneighborlabels==i);
   end
   for j=1:length(ss)
    vec=data(ss(j),:);    
    k=k+1; X2(k,:)=vec; labels2(1,k)=i;
   end
  end
 
  X=[X1;X2]; D=pdist(X,'euclidean'); D=squareform(D);
  sD=D(1:length(labels1),(length(labels1)+1):(length(labels1)+length(labels2)));

  for i=i1:i2
   for j=j1:j2
    s1=find(labels1==i); s2=find(labels2==j);
    tmpD=sD(s1,s2);
    val=mean(tmpD(:));
    regionpairD(i,j)=val;
    regionpairD(j,i)=val;
   end
  end

 end
end


% Generate the information about makers in the data.

[markerranks,seedpas,seeddescendants,Pseeds,markerpas,markerdescendants,markernoderanges,Pmarkers,subimageinds,subimagebds,seedregionmarkergroupvals,seedmarkergroupindicators,npartitionnodes,partitionnodes]=generate_markerinfo(data,nregions,regiontraininglabels,nseeds,seedinds);



% Run merge_seedregions_package.m.

[nmergeoutcomes,mergedclasslabels]=merge_seedregions_package(nseeds,seedinds,result_for_original,prob_for_original,combination_pairs,result_for_merge,result_for_removal,data,markerranks,regionneighborlabels,regionpairD,regiontraininglabels,[],0,[],usemarker,nprednumthre,pvalthre,nothersthre,cssizethre,ntoprankthre,quantilethre,nneighborsconsidered,ttestpvalthre,nuniquemarkersthre,importthre,replacementratiothre,localranksumpvalthre,cocontributionthre,reducedrankscorethre,confusionratiothre,ndiffthre,Hdthre,rankthre,datavalthre,datavaldiffthre,foldthre,cntthre,gapthre,maxgapcntthre,gapcntdiffthre,sizethre,jumpfoldthre,smallclustersizethre,gapfoldthre,smallratiothre,pdiffthre,pdiffthre2,medvalthre,ninformativemarkersthre,ninformativemarkersthre2,cntdiffthre);



% Report the merged seed classes.

filename=sprintf('%s',mergedclasslabelsfilename);
fout=fopen(filename,'w');
fprintf(fout,'index%cclass\n',9);
for n=1:nseeds
 fprintf(fout,'%d%c%d\n',seedinds(n),9,mergedclasslabels(n));
end
fclose(fout);


